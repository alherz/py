IMAPClient's release history is now part of the main
documentation_. See the `release documentation`_ on `Read the Docs`_ for
the most up-to-date details of IMAPClient's releases.

.. _documentation: http://imapclient.readthedocs.io/en/latest/
.. _release documentation: http://imapclient.readthedocs.io/en/latest/releases.html
.. _Read the Docs: http://readthedocs.org
